A simple chrome extension tool to get all of your recent Phabricator tickets based on your Phabricator profile.

Special thanks to Krizia Uayan for making the icons.

![screenshot](screenshot.png)
